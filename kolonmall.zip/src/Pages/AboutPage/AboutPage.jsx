import React from 'react'

function AboutPage() {
  return (
    <div>AboutPage</div>
  )
}

export default AboutPage