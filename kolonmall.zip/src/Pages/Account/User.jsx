import React from 'react'

function User() {
  /*
    유저스토리
    1. 헤더, 퓨터 html, css 작성 미디어쿼리 작성
    2. gnb 상품 클릭시 상품 전체 페이지가 나온다.,
    3.로그인 버튼을 누르면 로그인 페이지가 나온다
    
    4. 상품 클릭시 상품 디테일 페이지가 나온다.
    5. 상품 디테일을 눌렀으나 로그인이 안되었을 경우 로그인 페이지가 먼저 나온다.
    6. 로그인이 true일시 detail Page를 보게함
  */
  return (
    <div>User</div>
  )
}

export default User